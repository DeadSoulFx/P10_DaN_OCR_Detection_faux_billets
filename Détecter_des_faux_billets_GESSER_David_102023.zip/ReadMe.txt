_./ Instruction pour un fonctionnement optimal \._


1. Dézipper l'archive dans le même répertoire, exemple : ../User/Python/Projet_10
2. Vérifier que les fichiers suivants sont bien présents au même emplacement
	
	billets.csv
	billets_test_01.csv
	billet_test_02.csv
	GESSER_David_1_Preparation_102023.ipynb
	GESSER_David_2_DsFx_fct_102023.ipynb
	GESSER_David_3_Algo_102023.ipynb

3. Les fichiers .joblib sont optionnel, il sont créés lors de l'exécution du notebook : GESSER_David_1_Preparation_102023.ipynb
4. Ouvrir et exécuter : GESSER_David_1_Preparation_102023.ipynb




David GESSER
Data Analyst
MàJ : 28/12/2023